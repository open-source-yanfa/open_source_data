# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import json

import conf
import pymysql
import pymongo

from open_source_spider.spiders.factba import FactbaSpider
from open_source_spider.spiders.congress import CongressSpider


# 行程数据


class SpiderFactbaPipeline(object):
    def __init__(self, host, user, password, database, port):
        self.host = host
        self.user = user
        self.password = password
        self.database = database
        self.port = port

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            host=crawler.settings.get("MYSQL_HOST"),
            user=crawler.settings.get("MYSQL_USER"),
            password=crawler.settings.get("MYSQL_PASS"),
            database=crawler.settings.get("MYSQL_DATABASE"),
            port=crawler.settings.get("MYSQL_PORT"),
        )

    def open_spider(self, spider):
        '''负责连接数据库'''
        self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset="utf8", port=self.port)
        self.cursor = self.db.cursor()

    def process_item(self, item, spider):
        if isinstance(spider, FactbaSpider):
            # 组装sql语句
            if not item:
                return item
            data = dict(item)
            month, day, _time = data['month'], data['day'], data['time']
            year = month.strip().split(',')[-1]
            _month = conf.data_rev[month.split(',')[0].strip().lower()]
            time_ymd = str(year) + '-' + str(_month) + '-' + str(day)
            # 处理日期格式
            if _time != None:
                _time_hm = _time.strip().split()[0]
                hour, minu = _time_hm.split(':')[0], _time_hm.split(':')[1]
                if 'PM' in _time and int(hour) != 12:
                    hour = 12 + int(hour)
                time_format = str(time_ymd) + ' ' + str(hour) + ':' + str(minu) + ":00"
                time_save = time_format  # datetime.strptime(str(time_format), "%Y-%m-%d %H:%M:%S")
                data["format_data"] = time_save
                keys = ','.join(data.keys())
                values = ','.join(['%s'] * len(data))
                sql = "insert into %s(%s) values(%s)" % ('usppa_person_trip', keys, values)
                # 指定参数，并执行sql添加
                self.cursor.execute(sql, tuple(data.values()))
                # 事务提交
                self.db.commit()

                file_sql = "insert into usppa_person_trip %s " \
                           "values %s ;" % (str(tuple(data.keys())).replace("'", ''), str(tuple(data.values())))
                with open("open_source_spider/resource/zip_factba_file/data.sql", "a+", encoding="utf8") as f:
                    f.write(file_sql + '\n')

            if _time == None:
                time_format = str(time_ymd) + ' ' + str("00") + ':' + str("00") + ":00"
                data["format_data"] = time_format
                if data["time"] == None:
                    data["time"] = ""
                keys = ','.join(data.keys())
                values = ','.join(['%s'] * len(data))
                sql = "insert into %s(%s) values(%s)" % ('usppa_person_trip', keys, values)
                # 指定参数，并执行sql添加
                self.cursor.execute(sql, tuple(data.values()))
                # 事务提交
                self.db.commit()

                file_sql = "insert into usppa_person_trip %s " \
                           "values %s ;" % (str(tuple(data.keys())).replace("'", ''), str(tuple(data.values())))
                with open("open_source_spider/resource/zip_factba_file/data.sql", "a+", encoding="utf8") as f:
                    f.write(file_sql + '\n')

            return item
        else:
            # 如果不是这个spider爬虫，必须返回item，交给其他爬虫类处理。
            return item

    def close_spider(self, spider):
        '''关闭连接数据库'''
        self.db.close()


# 插入数据
insert_bill_number = 0
# 爬取数据
crawl_bill_number = 0


# 议案数据
class SpiderCongressPipeline(object):

    def __init__(self, mongo_url, mongo_db, mongo_table, mongo_port, mongo_user, mongo_pwd):
        self.mongo_url = mongo_url
        self.mongo_db = mongo_db
        self.mongo_table = mongo_table
        self.mongo_port = mongo_port
        self.mongo_user = mongo_user
        self.mongo_pwd = mongo_pwd

    @classmethod
    def from_crawler(cls, crawl):

        return cls(
            mongo_url=crawl.settings.get('MONGO_URL'),
            mongo_db=crawl.settings.get('MONGO_DB'),
            mongo_table=crawl.settings.get('MONGO_TABLE'),
            mongo_port=crawl.settings.get('MONGO_PORT'),
            mongo_user=crawl.settings.get('MONGO_USER'),
            mongo_pwd=crawl.settings.get('MONGO_PWD')
        )

    def open_spider(self, spider):
        '''
            爬虫一旦开启，就会实现这个方法，连接到数据库
        '''
        self.client = pymongo.MongoClient(self.mongo_url, self.mongo_port)
        self.db = self.client[self.mongo_db]
        self.db.authenticate(self.mongo_user, self.mongo_pwd, mechanism='SCRAM-SHA-1')

    def close_spider(self, spider):
        '''
            爬虫一旦关闭，就会实现这个方法，关闭数据库连接
        '''
        self.client.close()

    def process_item(self, item, spider):
        if isinstance(spider, CongressSpider):
            table = self.db[self.mongo_table]
            all_data = dict(item)

            global insert_bill_number
            # 查找本条议案是否存在
            congress_sign_number = table.count_documents({"congress_sign": all_data['congress_sign']})
            if congress_sign_number == 0:
                # 新增议案
                all_data['bill_status'] = '1'
                try:
                    # 写文件
                    with open("open_source_spider/resource/zip_congress_file/data.txt", "a+", encoding="utf8") as f:
                        f.write(json.dumps(all_data, ensure_ascii=False) + '\n')
                    table.insert_one(all_data)
                except Exception:
                    print("Document Too Large")
                insert_bill_number += 1
                print("insert success ", insert_bill_number, 'The new bill')

            if congress_sign_number > 0:
                latest_action_number = table.count_documents(
                    {"congress_sign": all_data['congress_sign'], "latest_action": all_data['latest_action']})
                # 修改议案
                if latest_action_number == 0:
                    all_data['bill_status'] = '2'
                    try:
                        with open("open_source_spider/resource/zip_congress_file/data.txt", "a+", encoding="utf8") as f:
                            f.write(json.dumps(all_data, ensure_ascii=False) + '\n')
                        table.insert_one(all_data)
                    except Exception:
                        print("Document Too Large")
                    insert_bill_number += 1
                    print("insert success ", insert_bill_number, 'Modify the bill')

            # 普通议案         第一次采集数据放开
            # if all_data['sponsor_time'] and all_data['tracker_list']:
            #     try:
            #         table.insert_one(all_data)
            #     except Exception:
            #         print("Document Too Large")
            #
            #     global crawl_bill_number
            #     crawl_bill_number += 1
            #     print("crawl_bill_number ", crawl_bill_number)

        else:
            # 如果不是这个spider爬虫，必须返回item，交给其他爬虫类处理。
            return item
