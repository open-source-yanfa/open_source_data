# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


# 行程数据
class SpiderFactbaItem(scrapy.Item):
    person_id = scrapy.Field()
    day = scrapy.Field()
    week = scrapy.Field()
    month = scrapy.Field()
    time = scrapy.Field()
    label = scrapy.Field()
    event = scrapy.Field()
    place = scrapy.Field()
    source = scrapy.Field()
    status = scrapy.Field()


# 议案数据
class SpiderCongressItem(scrapy.Item):
    news_title = scrapy.Field()
    person_id = scrapy.Field()
    bill_label = scrapy.Field()
    sponsor_time = scrapy.Field()
    introduced_date = scrapy.Field()
    sponsor = scrapy.Field()
    congress_time = scrapy.Field()
    congress_bill_type = scrapy.Field()
    congress_bill_number = scrapy.Field()
    congress_sign = scrapy.Field()
    summary_title = scrapy.Field()
    summary_list = scrapy.Field()
    committees = scrapy.Field()
    latest_action = scrapy.Field()
    tracker_list = scrapy.Field()
    subject = scrapy.Field()
    title_list = scrapy.Field()
    amendments_list = scrapy.Field()
    news_text_list = scrapy.Field()
    actions_overview_list = scrapy.Field()
    actions_list = scrapy.Field()
    cosponsor_list = scrapy.Field()
    committees_list = scrapy.Field()
    related_bills_list = scrapy.Field()

    web_url = scrapy.Field()
    bill_status = scrapy.Field()
    insert_time = scrapy.Field()
