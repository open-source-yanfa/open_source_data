# -*- coding: utf-8 -*-
import json
import os
from copy import deepcopy

import conf
import scrapy
import zipfile
import datetime

from scrapy import Request
from open_source_spider.items import SpiderFactbaItem
from dateutil.relativedelta import relativedelta
from open_source_spider.spiders.utils.datacheckout import data_checkout_util
from open_source_spider.spiders.utils.ftp_upload import *


class FactbaSpider(scrapy.Spider):
    name = 'factba'
    allowed_domains = ['www.factba.se']
    start_urls = ['https://factba.se/includes/calendar-row.php?json=calendar-october-2019.json']

    # realy_day = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
    realy_day = datetime.datetime.now()
    with open('time_spider', 'r', encoding='utf8') as f:
        time_spider = f.read()
    if time_spider:
        current_day = time_spider.strip()
    else:
        current_day = '2019-11-11'
    current_day = datetime.datetime.strptime(current_day, '%Y-%m-%d')
    current_day_is = deepcopy(current_day)

    stop = False

    def start_requests(self):
        # 增量爬取
        url = 'https://factba.se/includes/calendar-row.php?json=calendar-%s-%s.json' % (
            conf.data[str(self.current_day.month)], str(self.current_day.year))
        yield Request(url=url, callback=self.parse, dont_filter=True)

    def parse(self, response):
        list = response.css("tr")
        if not list:
            self.stop = True

        last_month = None
        last_week = None
        last_day = None
        for index, item in enumerate(list[1:]):
            item_spider = SpiderFactbaItem()
            # 日
            alist = item.css("td.agenda-date")
            if alist:
                items = alist[0]
                day = data_checkout_util(items.css("div.dayofmonth::text").extract_first())
                week = data_checkout_util(items.css("div.dayofweek::text").extract_first())
                month = data_checkout_util(items.css("div.shortdate::text").extract_first())
                if day:
                    last_month = month
                    last_week = week
                    last_day = day
            item_spider['person_id'] = "PRE0001"
            item_spider['day'] = last_day.strip()
            item_spider['week'] = last_week.strip()
            item_spider['month'] = last_month.strip()
            # 时间点
            items = item.css("td.agenda-time")
            if items:
                items = items[0]
                time = items.css("p::text").extract_first()
                label = data_checkout_util(items.css("div.agenda-label span::text").extract_first())

                if time != None:
                    item_spider['time'] = time.replace("\xa0", ' ')
                else:
                    item_spider['time'] = time
                item_spider['label'] = label.strip()
            # 内容
            items = item.css("td.agenda-events")
            if items:
                items = items[0]
                event = data_checkout_util(items.css("div.agenda-event div::text").extract_first())
                if not event.strip():
                    event = data_checkout_util(items.css("div.agenda-event div a ::text").extract_first())
                pullleft = data_checkout_util(items.css("div.agenda-event div .pull-left small::text").extract_first())
                pullright = data_checkout_util(
                    items.css("div.agenda-event div .pull-right small::text").extract_first())
                if event != None:
                    item_spider['event'] = event.replace("\r", '')
                else:
                    item_spider['event'] = event
                item_spider['place'] = pullleft
                item_spider['status'] = "1"
                item_spider['source'] = pullright.strip()
                # item['day'] = day
                # with open("spider_zw/zip_factba_file/data.sql", "a+", encoding="utf8") as f:
                #     f.write(json.dumps(dict(item_spider.items())) + '\n')
            month, day = item_spider['month'], item_spider['day']
            year = month.strip().split(',')[-1]
            _month = conf.data_rev[month.split(',')[0].strip().lower()]
            time_ymd = str(year) + '-' + str(_month) + '-' + str(day)
            time_ymd = datetime.datetime.strptime(time_ymd, '%Y-%m-%d')
            if index == 0:
                if time_ymd <= self.realy_day:
                    with open('time_spider', 'w+', encoding="utf8") as f:
                        f.write(datetime.datetime.strftime(time_ymd, '%Y-%m-%d'))

            if time_ymd <= self.current_day_is:
                if time_ymd <= self.current_day:
                    yield None
                yield None
            else:
                yield item_spider

        print(self.stop)
        # 当前月份 + 1
        self.current_day = self.current_day + relativedelta(months=1)
        if not self.stop:
            url = 'https://factba.se/includes/calendar-row.php?json=calendar-%s-%s.json' % (
                conf.data[str(self.current_day.month)], str(self.current_day.year))

            print(url)
            yield Request(url=url, callback=self.parse, dont_filter=True)
        else:
            file_path = "open_source_spider/resource/zip_factba_file/data.sql"
            # 压缩文件
            zip_path = "open_source_spider/resource/zip_factba_package/" + str(datetime.datetime.now())[:10] + '.zip'
            zp = zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED)
            zp.write(file_path, 'data.sql')  # 如果不添加arcname参数，则压缩后，会出现一堆路径上的目录文件夹
            zp.close()
            # 将压缩的文件上传FTP 服务器
            connect = FtpConnect('223.223.177.101', 'internet-data', 'yqjc47ftp*')
            # connect = FtpConnect('192.168.10.216', 'ftptest10', '987654321')
            # 清空FTP服务器的所有文件
            # FtpDeleteAll(connect)
            FtpUpload(connect, '/journey/' + str(datetime.datetime.now())[:10] + '.zip', zip_path)
            # 判断文件是否存在
            if (os.path.exists(file_path)):
                os.remove(file_path)
                print("File deleted successfully")
