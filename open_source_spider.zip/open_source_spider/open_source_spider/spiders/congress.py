# -*- coding: utf-8 -*-
import datetime
import json
import random
import re
import time
import zipfile
import urllib3
import requests
import scrapy
from lxml import etree
from requests.adapters import HTTPAdapter
from scrapy import Request
from fake_useragent import UserAgent

from open_source_spider.items import SpiderCongressItem
from open_source_spider.spiders.utils.read_csv import *

urllib3.disable_warnings()


class CongressSpider(scrapy.Spider):
    name = 'congress'
    allowed_domains = ['www.congress.gov']
    # 下面request使用
    headers = {
        'user-agent': UserAgent().random,
    }
    header = {
        ':authority': 'www.congress.gov',
        ':method': 'GET',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
        'accept-encoding': 'gzip, deflate, br',
        'accept-language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
        'cache-control:': 'max-age=0',
        'user-agent': UserAgent().random,
        'cookie': '__cfduid=de1e043ce48f0ecd83a1a85283218d8091575267482; s_vi=[CS]v1|2EF2564E8515C02C-600008E4D447BAAF[CE]; quickSearchFormExpanded=0; s_cc=true; s_sess=%20s_cc%3Dtrue%3B%20s_sq%3D%3B; s_fid=20C47C696D5427B6-0DBDCD045A74AFA7; actionsSearchResultViewType=expanded; overview_hidden=%5B%22%2Fbill%2F116th-congress%2Fhouse-resolution%2F393%22%2C%22%2Fbill%2F116th-congress%2Fsenate-bill%2F2320%22%5D; post-authentication-url=%2Fbill%2F116th-congress%2Fsenate-bill%2F2320%2Ftext%3Fformat%3Dtxt%26q%3D%257B%2522search%2522%253A%255B%2522china%2522%255D%257D%26r%3D1%26s%3D1; searchResultViewType%2Fsearch=compact; s_sq=%5B%5BB%5D%5D; PHPSESSID=b9g37cdn82ov4f509vi8gsjq95'
    }
    spider_index = 0
    urls = []

    def start_requests(self):

        # yield Request(url='https://www.congress.gov/bill/116th-congress/senate-bill/178/all-info', callback=self.parse,
        #               dont_filter=True, headers=self.headers)

        # yield Request(url='https://www.congress.gov/bill/116th-congress/house-bill/704/all-info',
        #               callback=self.parse,
        #               dont_filter=True, headers=self.headers)
        # Amendments
        # yield Request(url='https://www.congress.gov/bill/116th-congress/senate-bill/1838/all-info',
        #               callback=self.parse,
        #               dont_filter=True, headers=self.headers)
        # Committees
        # yield Request(url='https://www.congress.gov/bill/116th-congress/house-bill/704/all-info',
        #               callback=self.parse,
        #               dont_filter=True, headers=self.headers)
        # Summary
        # yield Request(url='https://www.congress.gov/bill/116th-congress/senate-bill/178/all-info',
        #               callback=self.parse,
        #               dont_filter=True, headers=self.headers)
        #
        # for all_info_url in read_csv():
        #     time.sleep(2)
        #     yield Request(url=all_info_url[1], callback=self.parse, dont_filter=False, headers=self.header)
        # # break

        self.urls = read_csv()
        time.sleep(2)
        yield Request(url=self.urls[self.spider_index], callback=self.parse, dont_filter=False, headers=self.header)

    def parse(self, response):
        item_spider = SpiderCongressItem()
        request = requests.session()
        request.adapters.DEFAULT_RETRIES = 10  # 增加requests重连次数
        request.mount('https://', HTTPAdapter(max_retries=10))  # 增加requests重连次数
        request.keep_alive = False  # 关闭多余连接

        news_info_title = response.xpath('//*[@id="content"]/div[1]/h1/text()').extract_first().replace(
            "All Information (Except Text) for ", "")
        # 议案标签
        bill_label = response.xpath('//*[@class="label_text"]/text()').extract_first()
        sponsor_a = response.xpath(
            '//table[@class="standard01"]/tr[1]/td/a/text()').extract_first()
        sponsor_time = response.xpath(
            '//*[@class="standard01"]/tr[1]/td/text()').extract_first()
        sponsor_person_id = response.xpath(
            '//table[@class="standard01"]/tr[1]/td/a/@href').extract_first()
        sponsor = sponsor_a + sponsor_time
        # Introduced
        introduced_date = sponsor_time.replace('(', '').replace(')', '')
        # 格式化sponsor 时间
        try:
            sponsor_time = sponsor_time[-11:].replace(')', '')
            sponsor_strftime = datetime.datetime.strptime(sponsor_time, '%m/%d/%Y')
            format_sponsor_time = datetime.datetime.strftime(sponsor_strftime, '%Y-%m-%d')
        except Exception as e:
            with open('exception_url.txt', 'a+') as file:
                file.write(response.url + '/n')
            format_sponsor_time = ''
        if not format_sponsor_time:
            print(response.url)

        # 议案提出人
        person_id = sponsor_person_id[-7:]
        # 议案提出时间
        sponsor_time = format_sponsor_time

        # script_text = response.xpath('//*[@id="content"]/div[1]/script/text()').extract_first()
        # re_item = re.findall('params:(.*?)route:', script_text, re.S)
        # re_item = json.loads(re_item[0].strip()[:-1])

        # 届次                                             正则匹 获取
        # congress_time = re_item['congress']
        congress_time = response.url.split('/')[-4:-3][0]
        # print(response.url.split('/')[-4:-3][0])  # 从URL 获取
        # 议案类型
        # congress_bill_type = re_item['billType']
        congress_bill_type = response.url.split('/')[-3:-2][0]
        # print(response.url.split('/')[-3:-2][0])
        # 议案数量
        # congress_bill_number = re_item['billNumber']
        congress_bill_number = response.url.split('/')[-2:-1][0]
        # print(response.url.split('/')[-2:-1][0])
        # 议案标识
        congress_sign = congress_time + '_' + congress_bill_type + '_' + congress_bill_number

        committees_th = response.xpath('//*[@class="standard01"]/tr[2]/th/text()').extract_first()
        if (committees_th.strip() if committees_th else '') == 'Committees:':
            committees = response.xpath('//*[@class="standard01"]/tr[2]/td/text()').extract_first()
        else:
            committees_th = response.xpath('//*[@class="standard01"]/tr[3]/th/text()').extract_first()
            if (committees_th.strip() if committees_th else '') == 'Committees:':
                committees = response.xpath('//*[@class="standard01"]/tr[3]/td/text()').extract_first()
            else:
                committees = ''

        latest_action_two = response.xpath('//*[@class="standard01"]/tr[3]/td/text()').extract_first()
        # 校验latest_action前半部分是否为latest_action数据
        latest_action_th = response.xpath('//*[@class="standard01"]/tr[3]/th/text()').extract_first()
        if (latest_action_th.strip() if latest_action_th else '') == 'Latest Action:':
            latest_action = latest_action_two.replace("(", '').replace(" (text: CR", '')
        else:
            latest_action = response.xpath('//*[@class="standard01"]/tr[4]/td/text()').extract_first()
            # 校验latest_action前半部分是否为latest_action数据
            latest_action_th = response.xpath('//*[@class="standard01"]/tr[4]/th/text()').extract_first()
            if (latest_action_th.strip() if latest_action_th else '') == 'Latest Action:':
                latest_action = latest_action.replace("(", '').replace(" (text: CR", '')
            else:
                latest_action = response.xpath('//*[@class="standard01"]/tr[5]/td/text()').extract_first()
                # 校验latest_action前半部分是否为latest_action数据
                latest_action_th = response.xpath('//*[@class="standard01"]/tr[5]/th/text()').extract_first()
                if (latest_action_th.strip() if latest_action_th else '') == 'Latest Action:':
                    latest_action = latest_action.replace("(", '').replace(" (text: CR", '')
                else:
                    latest_action = response.xpath('//*[@class="standard01"]/tr[2]/td/text()').extract_first()
                    # 校验latest_action前半部分是否为latest_action数据
                    latest_action_th = response.xpath('//*[@class="standard01"]/tr[2]/th/text()').extract_first()
                    if (latest_action_th.strip() if latest_action_th else '') == 'Latest Action:':
                        latest_action = latest_action.replace("(", '').replace(" (text: CR", '')

        # 所有Tracker的信息
        all_tracker_list = []
        all_tracker = response.xpath('//*[@id="content"]/div[1]/div[3]/div[1]/div[1]/ol/li')
        for tracker in all_tracker:
            all_tracker_content = tracker.xpath('text()').extract_first()
            selected_status = tracker.xpath('attribute::*').extract_first()
            # 判断 tracker的选中状态  1为选中
            if 'selected' in (selected_status if selected_status != None else " "):
                all_tracker_list.append({'tracker': all_tracker_content, 'status': '1'})
            else:
                all_tracker_list.append({'tracker': all_tracker_content, 'status': '0'})

        subject = response.xpath('(//*[@class="tertiary_section"])[last()]/ul/li/text()').extract_first()

        # 获取 Summary
        all_summary_list = []
        summary_respons = request.get(response.url.split('/all-info')[0] + '/summary', timeout=60, headers=self.headers,
                                      verify=False)
        summary_header_info = ''
        if summary_respons.status_code == 200:
            summary_respons.encoding = 'utf-8'
            html_element = etree.HTML(summary_respons.content)
            summary_xpath = html_element.xpath("//*[@id='summaryId']/option")
            # summary页大标题       Summary: H.R.704 — 116th Congress (2019-2020)
            summary_header_info = str(html_element.xpath("//*[@class='primary']/text()")[0])
            # 多篇
            if summary_xpath:
                for index, text_value in enumerate(summary_xpath):
                    # 解析 Option 的值
                    text_select_value = text_value.attrib.get("value")
                    # 解析 下拉框内容的值
                    text_select_lable = text_value.xpath("string(text())")
                    # 解析下拉框 的text内容
                    summary_option_content = text_value.xpath(
                        'string(//*[@id="summaryId"]/option[' + str(index + 1) + '])')
                    every_select_option_resp = request.get(
                        response.url.split('/all-info')[0] + '/summary/' + text_select_value, timeout=60,
                        headers=self.headers, verify=False)
                    if every_select_option_resp.status_code == 200:
                        every_select_option_resp.encoding = 'utf-8'
                        html_element = etree.HTML(every_select_option_resp.content)
                        summary_header_element = html_element.xpath("//*[@id='bill-summary']/p[1]")
                        summary_header = etree.tostring(summary_header_element[0], encoding="utf-8", pretty_print=True,
                                                        method="html")

                        # 获取id='bill-summary下的标签
                        bill_summary_list = []
                        for content_number in range(2, 20):
                            summary_title_element = html_element.xpath(
                                '//*[@id="bill-summary"]/p[' + str(content_number) + ']')
                            every_summary_content = html_element.xpath(
                                'string(//*[@id="bill-summary"]/p[' + str(content_number) + '])')
                            if every_summary_content:
                                bill_summary_list.append(every_summary_content)

                            # try:
                            #     summary_title = etree.tostring(summary_title_element[0], encoding="utf-8",
                            #                                    pretty_print=True,
                            #                                    method="html")
                            #     summary_content_element = html_element.xpath(
                            #         '//*[@id="bill-summary"]/ul[' + str(
                            #             content_number - 1) + ']')
                            #
                            #     if summary_title_element != '' or summary_title_element != ' ':
                            #         for summary_content_xpath in summary_content_element:
                            #             summary_content = summary_content_xpath.xpath('string()')
                            #             bill_summary_list.append(
                            #                 {'summary_option_content': text_select_lable,
                            #                  'summary_title': str(summary_title, encoding="utf-8").replace("<p>",
                            #                                                                                '').replace(
                            #                      "</p>", '').replace('\n', ''),
                            #                  'summary_content': str(summary_content).replace("<p>", '').replace("</p>",
                            #                                                                                     '').replace(
                            #                      '\n', '')})
                            # except Exception:
                            #     break

                        # 如果标题有数据  方法较LOW ^_^
                        if bill_summary_list:
                            all_summary_list.append(
                                {'summary_header': str(summary_header, encoding='utf-8').replace("<p>",
                                                                                                 '').replace(
                                    "</p>", '').replace('\n', '').replace('<b>', '').replace('</b>', ''),
                                 'summary_option_content': text_select_lable,
                                 'bill_summary': bill_summary_list})
                        else:
                            all_summary_list.append(
                                {'summary_header': [],
                                 'summary_option_content': text_select_lable,
                                 'bill_summary': [str(summary_header, encoding='utf-8').replace("<p>",
                                                                                                '').replace(
                                     "</p>", '').replace('\n', '').replace('<b>', '').replace('</b>', '')]})
                    every_select_option_resp.close()
            else:
                every_select_option_resp = request.get(
                    response.url.split('/all-info')[0] + '/summary', timeout=60, headers=self.headers, verify=False)
                if every_select_option_resp.status_code == 200:
                    every_select_option_resp.encoding = 'utf-8'
                    html_element = etree.HTML(every_select_option_resp.content)
                    # 小标题   Uighur Intervention and Global Humanitarian Unified Response Act of 2018 or the UIGHUR Act of 2018
                    summary_header = html_element.xpath("string(//*[@id='bill-summary']/p[1]/b)")
                    # 获取id='bill-summary下的标签
                    bill_summary_list = []
                    for content_number in range(2, 20):
                        # 有小标题   标题内容在第二个P标签下
                        summary_title_element = html_element.xpath(
                            '//*[@id="bill-summary"]/p[' + str(content_number) + ']')
                        # 小标题下的内容
                        every_summary_content = html_element.xpath(
                            'string(//*[@id="bill-summary"]/p[' + str(content_number) + '])')

                        if every_summary_content:
                            bill_summary_list.append(every_summary_content)

                    if summary_header or bill_summary_list:
                        all_summary_list.append({'summary_header': summary_header.replace('\n', ''),
                                                 'bill_summary': bill_summary_list})
                every_select_option_resp.close()
            summary_respons.close()

        # 获取Title
        all_titile_list = []
        titles = response.xpath('//*[@id="titles_main"]')
        for title in titles:
            # shortTitle
            # check_null_short_titles = title.xpath('div[@class="shortTitles"]/h3/text()').extract_first()
            # if check_null_short_titles:
            #     all_titile_list.append({"short_titles": check_null_short_titles})

            # titles-row
            check_null_data = title.xpath('div[@class="titles-row"]').extract_first()
            if check_null_data:
                for_titles = title.xpath('div[@class="titles-row"]/div')
                # 循环获取所有Short Titles
                short_title_list = []  # 一条完整的数据
                for short_title in for_titles:
                    every_items = short_title.xpath('*')
                    num_list = []
                    set_num_list = []
                    for index, item in enumerate(every_items):
                        if index != 0:
                            # 获取除了第一行的所有数据的数量  除以二 得到每一对新闻的数量
                            index_list = index / 2
                            num_list.append(int(index_list))
                            for every_num in num_list:
                                if every_num not in set_num_list:
                                    if every_num != 0:
                                        set_num_list.append(every_num)

                    for i in range(len(set_num_list)):
                        # 第二个 H4  Short Titles as Passed Senate
                        titles_title = short_title.xpath('h4[' + str(i + 2) + ']/text()').extract_first()
                        # 第一个 P  Uyghur Human Rights Policy Act of 2019
                        titles_small_content = short_title.xpath('p[' + str(i + 1) + ']/text()').extract_first()
                        # Short Titles - Senate
                        titles_header = short_title.xpath('h4[1]/text()').extract_first()

                        # 判断 H5 标签是否有数据   有的有H5标签,有的没有
                        titles_h5_title = short_title.xpath('h5[' + str(i + 1) + ']/text()').extract_first()
                        titles_h5_content = short_title.xpath('string(ul[' + str(i + 1) + ']/li)').extract_first()
                        # 若没有h5数据
                        if not titles_h5_title or not titles_h5_title.strip():
                            if (i + 2) == 2:
                                if titles_header and titles_header.strip() and titles_title:
                                    short_title_list.append(
                                        {'short_titles_header': titles_header, 'titles_title_header': titles_title,
                                         'titles_small_content': titles_small_content})
                                else:
                                    if titles_header and titles_header.strip() and titles_title:
                                        short_title_list.append({'titles_title_header': titles_title,
                                                                 'titles_small_content': titles_small_content})
                            else:
                                if titles_header and titles_header.strip() and titles_title:
                                    short_title_list.append(
                                        {'titles_title_header': titles_title,
                                         'titles_small_content': titles_small_content})
                        # 有h5数据
                        else:
                            if (i + 2) == 2:
                                # 判断 如果titles_header有数据才添加
                                if titles_header:
                                    short_title_list.append(
                                        {'short_titles_header': titles_header, 'titles_title_header': titles_title,
                                         'titles_small_content': titles_small_content,
                                         'titles_h5_title': titles_h5_title,
                                         'titles_h5_content': titles_h5_content})
                                else:
                                    short_title_list.append({'titles_title_header': titles_title,
                                                             'titles_small_content': titles_small_content,
                                                             'titles_h5_title': titles_h5_title,
                                                             'titles_h5_content': titles_h5_content
                                                             })
                            else:
                                # 如果 h5 标题 不等于空
                                if titles_h5_title:
                                    short_title_list.append(
                                        {'titles_title_header': titles_title,
                                         'titles_small_content': titles_small_content,
                                         'titles_h5_title': titles_h5_title,
                                         'titles_h5_content': titles_h5_content
                                         })

                all_titile_list.append({"short_titles": short_title_list})
            # official
            check_null_official = title.xpath('div[@class="officialTitles"]').extract_first()
            if check_null_official:
                for_titles = title.xpath('//*[@id="titles_main"]/div[3]/div[2]/div')
                # official 有两种结构   根据有无数据判断
                if len(for_titles) == 0:
                    for_titles = title.xpath('//*[@id="titles_main"]/div/div[2]/div')
                # 循环获取所有official Titles
                official_title_list = []  # 一条完整的数据
                for official_title in for_titles:
                    every_items = official_title.xpath('*')
                    num_list = []
                    set_num_list = []
                    for index, item in enumerate(every_items):
                        if index != 0:
                            # 获取除了第一行的所有数据的数量  除以二 得到每一对新闻的数量
                            index_list = index / 2
                            num_list.append(int(index_list))
                            for every_num in num_list:
                                if every_num not in set_num_list:
                                    if every_num != 0:
                                        set_num_list.append(every_num)
                    for i in range(len(set_num_list)):

                        # 大标题
                        # official_titles = title.xpath('div[@class="officialTitles"]/h3/text()').extract_first()

                        official_titles_senate = official_title.xpath('h4[' + str(i + 2) + ']/text()').extract_first()
                        official_small_content = official_title.xpath('p[' + str(i + 1) + ']/text()').extract_first()

                        official_titles_header = official_title.xpath('h4[1]/text()').extract_first()
                        # 从第二个标签开始 ,第一个{}追加titles_title_header,否则不加titles_title_header
                        if (i + 2) == 2:
                            if official_titles_header:
                                official_title_list.append(
                                    {'short_titles_header': official_titles_header,
                                     'titles_title_header': official_titles_senate,
                                     'titles_small_content': official_small_content})
                            else:
                                if official_titles_senate:
                                    official_title_list.append({'titles_title_header': official_titles_senate,
                                                                'titles_small_content': official_small_content})
                        else:
                            if official_titles_senate:
                                official_title_list.append(
                                    {'titles_title_header': official_titles_senate,
                                     'titles_small_content': official_small_content})

                all_titile_list.append({'official_titles': official_title_list})

        # 获取文章内容Text
        all_news_text_list = []
        resp = request.get(response.url.split('/all-info')[0] + '/text', timeout=120, headers=self.headers,
                           verify=False)
        if resp.status_code == 200:
            resp.encoding = 'utf-8'
            html_element = etree.HTML(resp.content)
            xpath = html_element.xpath("//*[@id='textVersion']/option")
            # 获取多篇文章内容Text
            if xpath:
                for text_value in xpath:
                    # news_many_text_list = []
                    text_select_value = text_value.attrib.get("value")
                    # 解析TEXT页  下拉框的值
                    text_select_lable = text_value.xpath("string(text())")
                    # 解析TEXT内容 带样式
                    # https://www.congress.gov/bill/116th-congress/house-resolution/393/text/ih
                    resp = request.get(response.url.split('/all-info')[0] + '/text/' + text_select_value, timeout=120,
                                       headers=self.headers, verify=False)
                    if resp.status_code == 200:
                        resp.encoding = 'utf-8'
                        html_element = etree.HTML(resp.content)
                        conten_css = html_element.xpath('//div[contains(@class,"generated-html-container")]')
                        if conten_css:
                            content = etree.tostring(conten_css[0], encoding="utf-8", pretty_print=True,
                                                     method="html")
                            # re_content = r'<a[^>]+?id=["\']?([^"\']+)["\']?[^>]*>([^<]+)</a>'
                            # content = re.sub(re_content, "", need_re_content)
                        else:
                            content = b''
                    resp.close()
                    # 解析TEXT内容  不带样式
                    # https://www.congress.gov/bill/116th-congress/house-resolution/393/text/ih?format=txt
                    resp = request.get(
                        response.url.split('/all-info')[0] + '/text/' + text_select_value + '?format=txt', timeout=60,
                        headers=self.headers, verify=False)
                    if resp.status_code == 200:
                        resp.encoding = 'utf-8'
                        html_element = etree.HTML(resp.content)
                        content_text = html_element.xpath('//*[@id="billTextContainer"]/text()')[0]
                        all_news_text_list.append(
                            {'content_option_value': text_select_lable, 'content': str(content, encoding='utf-8'),
                             'content_text': content_text})
                    resp.close()

            else:
                # 获取单篇文章内容Text
                news_text_list = {}
                # 解析TEXT内容 带样式
                # https://www.congress.gov/bill/116th-congress/house-resolution/393/text
                try:
                    resp = request.get(response.url.split('/all-info')[0] + '/text', timeout=60, headers=self.headers,
                                       verify=False)
                    if resp.status_code == 200:
                        resp.encoding = 'utf-8'
                        html_element = etree.HTML(resp.content)
                        conten_css = html_element.xpath('//div[contains(@class,"generated-html-container")]')
                        if conten_css:
                            content = etree.tostring(conten_css[0], encoding="utf-8", pretty_print=True, method="html")
                            news_text_list['content'] = str(content, encoding='utf-8')
                    resp.close()
                    # 解析TEXT内容  不带样式
                    # https://www.congress.gov/bill/116th-congress/house-resolution/393/text?format=txt
                    resp = request.get(
                        response.url.split('/all-info')[0] + '/text?format=txt', timeout=60, headers=self.headers,
                        verify=False)
                    if resp.status_code == 200:
                        resp.encoding = 'utf-8'
                        html_element = etree.HTML(resp.content)
                        try:
                            content_text = html_element.xpath('//*[@id="billTextContainer"]/text()')[0]
                        except:
                            content_text = ''
                        news_text_list['content_text'] = content_text
                        all_news_text_list.append(news_text_list)
                    resp.close()
                except Exception as e:
                    pass
        resp.close()

        # 获取ActionsOverview
        all_actions_overview_list = []
        check_null_actions_view = response.xpath(
            '//*[@id="actionsOverview-content"]/table/tbody/tr[1]/td[1]').extract_first()
        if check_null_actions_view:
            for_actions_data = response.xpath('//*[@id="actionsOverview-content"]/table/tbody/tr')
            for all_actions in for_actions_data:
                actions_date = all_actions.xpath('td[1]/text()').extract_first()
                actions_content = all_actions.xpath('string(td[2])').extract_first()
                all_actions_overview_list.append(
                    {'actions_overview_date': actions_date, 'actions_overview_content': actions_content})

        # 获取Actions
        all_actions_list = []
        check_null_actions = response.xpath(
            '//*[@id="allActions-content"]/table/tbody/tr').extract_first()
        if check_null_actions != None and check_null_actions != '':
            for_actions_data = response.xpath('//*[@id="allActions-content"]/table/tbody/tr')
            for all_actions in for_actions_data:
                # 判断 All Actions的数量 有的为3列 有的为2列
                if len(all_actions.xpath('td')) > 2:
                    actions_date = all_actions.xpath('td[1]/text()').extract_first()
                    chamber_date = all_actions.xpath('td[2]/text()').extract_first()
                    actions_content = all_actions.xpath('string(td[3])').extract_first()
                    all_actions_list.append({'all_actions_date': actions_date, 'all_chamber_date': chamber_date,
                                             'all_actions_content': actions_content})
                else:
                    actions_date = all_actions.xpath('td[1]/text()').extract_first()
                    actions_content = all_actions.xpath('string(td[2])').extract_first()
                    all_actions_list.append({'all_actions_date': actions_date, 'all_actions_content': actions_content})

        # 获取Amendments
        # https://www.congress.gov/bill/116th-congress/senate-bill/504/amendments
        all_amendments_list = []
        amendments_resp = request.get(response.url.split('/all-info')[0] + '/amendments?pageSize=250', timeout=60,
                                      headers=self.headers, verify=False)
        if amendments_resp.status_code == 200:
            amendments_resp.encoding = 'utf-8'
            html_element = etree.HTML(amendments_resp.content)
            amendments_element = html_element.xpath('//*[@id="main"]/ol/li[contains(@class,"expanded")]')

            for index, every_amendments in enumerate(amendments_element):
                if len(every_amendments) == 3:
                    amendments_header = every_amendments.xpath('string(span[1])')
                    amendments_sponsor = every_amendments.xpath('string(span[2])')
                    amendments_action = every_amendments.xpath('span[3]/text()')

                    all_amendments_list.append({'amendments_header': str(amendments_header),
                                                'amendments_sponsor': str(amendments_sponsor).replace("Sponsor:",
                                                                                                      '').replace('\n',
                                                                                                                  '').replace(
                                                    '            ', '').replace('\n', ''),
                                                'amendments_action': str(amendments_action[0]).replace('  (',
                                                                                                       '').replace(
                                                    '\n', '')})

                if len(every_amendments) == 4:
                    amendments_header = every_amendments.xpath('string(span[1])')
                    amendments_purpose = every_amendments.xpath('span[2]/text()')
                    amendments_sponsor = every_amendments.xpath('string(span[3])')
                    amendments_action = every_amendments.xpath('string(span[4])')

                    all_amendments_list.append({'amendments_header': str(amendments_header),
                                                'amendments_purpose': str(amendments_purpose[0]).replace('  ',
                                                                                                         '').replace(
                                                    '\n', ''),
                                                'amendments_sponsor': str(amendments_sponsor).replace("Sponsor:",
                                                                                                      '').replace('\n',
                                                                                                                  '').replace(
                                                    '                 ', ''),
                                                'amendments_action': str(amendments_action).replace(
                                                    '                    Latest Action:', '').replace('  (All Actions)',
                                                                                                      '').replace('\n',
                                                                                                                  '')})
        amendments_resp.close()

        # 获取Cosponsors
        all_cosponsor_list = []
        cosponsors_data = response.xpath('//*[@id="cosponsors-content"]/div[1]/table/tbody/tr')
        for cosponsor in cosponsors_data:
            cosponsor_person = cosponsor.xpath('td/a/@href').extract_first()[-7:]
            cosponsor_title = cosponsor.xpath('td/a/text()').extract_first()
            cosponsor_date = cosponsor.xpath('td[2]/text()').extract_first()
            all_cosponsor_list.append({'cosponsor_person': cosponsor_person, 'cosponsor_title': cosponsor_title,
                                       'cosponsor_date': cosponsor_date})

        # 获取Committees
        all_committees_list = []
        # committees_header 头部固定
        # committees_header = 'Committees, subcommittees and links to reports associated with this bill are listed here, as well as the nature and date of committee activity and Congressional report number.'
        committees_data = response.xpath('//*[@id="committees_main"]/table/tbody/tr')
        for index, committes in enumerate(committees_data):
            committees_data_list = []
            attr = committes.xpath('./attribute::*')
            cl = attr.get('class')
            if cl == 'class' or cl == 'subcommittee':
                continue
            subcommittee_title = committes.xpath('th/text()').extract_first()
            date_date = committes.xpath('td[1]/text()').extract_first()
            activity_date = committes.xpath('td[2]/text()').extract_first()
            reports_date = committes.xpath('td[3]/text()').extract_first()
            # 有的 reports 内容为空 在a 标签下
            if not reports_date:
                reports_date = committes.xpath('td[3]/a/text()').extract_first()

            committees_data_list.append(
                {'committees_subcommittee_title': subcommittee_title, 'committees_date': date_date,
                 'committees_activity': activity_date, 'committees_reports': reports_date if reports_date else ''})
            # if not subcommittee_title:
            nex_index = index
            while True:
                nex_index += 1
                if nex_index > len(committees_data) - 1:
                    break
                nex_committes = committees_data[nex_index]
                nex_attr = nex_committes.xpath('./attribute::*')
                cl = nex_attr.get('class')
                if cl == 'class' or cl == 'subcommittee':
                    subcommittee_small_title = nex_committes.xpath('th/text()').extract_first()
                    date_date = nex_committes.xpath('td[1]/text()').extract_first()
                    activity_date = nex_committes.xpath('td[2]/text()').extract_first()
                    reports_date = nex_committes.xpath('td[3]/text()').extract_first()
                    if not reports_date:
                        reports_date = nex_committes.xpath('td[3]/a/text()').extract_first()
                    # if 二级标题头没有数据 则用一级标题头数据
                    if not subcommittee_small_title:
                        subcommittee_small_title = subcommittee_title
                    committees_data_list.append(
                        {'committees_subcommittee_title': subcommittee_small_title, 'committees_title': date_date,
                         'committees_activity': activity_date,
                         'committees_reports': reports_date if reports_date else ''})
                    pass
                else:
                    break
            all_committees_list.append({'committees_subcommittee_list': committees_data_list})

        # 获取Related Bills
        all_related_bills_list = []
        related_bills_data = response.xpath('//*[@id="related_main"]/div/table/tbody/tr')
        if related_bills_data:
            for related_bills in related_bills_data:
                try:
                    bill_data = related_bills.xpath('string(td[1])').extract_first().replace('\n', '').replace(' ', '')
                    # 相关法案链接
                    relation_bill_sign = related_bills.xpath('td[1]/a/@href').extract_first().split('/')[-3:]
                    relation_bill_sign = relation_bill_sign[0] + '_' + relation_bill_sign[1] + '_' + relation_bill_sign[
                        2]
                    latest_title = related_bills.xpath('td[2]/text()').extract_first()
                    relationships_data = related_bills.xpath('td[3]/text()').extract_first()
                    identified_data = related_bills.xpath('td[4]/text()').extract_first()
                    bill_latest_action = related_bills.xpath('td[5]/text()').extract_first()
                    all_related_bills_list.append(
                        {'relation_bill_sign': relation_bill_sign, 'bill_data': bill_data, 'latest_title': latest_title,
                         'relationships_data': relationships_data, 'identified_data': identified_data,
                         'latest_action': bill_latest_action})
                except Exception:
                    pass
        else:
            # 没有数据
            all_related_bills_list.append({'none_data': response.xpath('string(//*[@id="main"]/p)').extract_first()})

        item_spider["news_title"] = news_info_title
        item_spider["person_id"] = person_id
        item_spider["bill_label"] = bill_label
        item_spider["sponsor_time"] = sponsor_time
        item_spider["introduced_date"] = introduced_date
        item_spider["sponsor"] = sponsor
        item_spider["congress_time"] = congress_time
        item_spider["congress_bill_type"] = congress_bill_type
        item_spider["congress_bill_number"] = congress_bill_number
        item_spider["congress_sign"] = congress_sign
        item_spider["summary_title"] = summary_header_info
        item_spider["summary_list"] = all_summary_list
        item_spider["committees"] = committees
        item_spider["latest_action"] = latest_action
        item_spider["tracker_list"] = all_tracker_list
        item_spider["subject"] = subject
        item_spider["title_list"] = all_titile_list
        item_spider["amendments_list"] = all_amendments_list
        item_spider["news_text_list"] = all_news_text_list
        item_spider["actions_overview_list"] = all_actions_overview_list
        item_spider["actions_list"] = all_actions_list
        item_spider["cosponsor_list"] = all_cosponsor_list
        item_spider["committees_list"] = all_committees_list
        item_spider["related_bills_list"] = all_related_bills_list

        item_spider["insert_time"] = str(time.strftime('%Y-%m-%d %H:%M:%S'))
        item_spider["bill_status"] = '0'
        item_spider["web_url"] = str(response.url)
        yield item_spider

        self.spider_index += 1
        if self.spider_index <= len(self.urls) - 1:
            yield Request(url=self.urls[self.spider_index], callback=self.parse, dont_filter=False,
                          headers=self.header)
        else:
            pass

            # 要压缩的文件路径
            file_path = "open_source_spider/resource/zip_congress_file/data.txt"
            # 压缩文件
            zip_path = "open_source_spider/resource/zip_congress_package/" + str(datetime.datetime.now())[:10] + '.zip'
            zp = zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED)
            zp.write(file_path, 'data.txt')  # 如果不添加arcname参数，则压缩后，会出现一堆路径上的目录文件夹
            zp.close()

            # # 判断文件是否存在
            if (os.path.exists(file_path)):
                os.remove(file_path)
                print("File deleted successfully", file_path)
