sql_info = {
    'ip': '192.168.10.222',
    'port': '3306',
    'user': 'root',
    'pwd': '123456',
    'database': 'usppa_dev'
}