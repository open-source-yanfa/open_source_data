import datetime
import time

from dateutil import rrule


# 获取从开始日期到结束日期查询存在的月份列表
def get_month_range(start_month, end_month):
    start_time = datetime.datetime.strptime(start_month, "%Y-%m")
    end_time = datetime.datetime.strptime(end_month, "%Y-%m")
    month_count = rrule.rrule(rrule.MONTHLY, dtstart=start_time, until=end_time).count()
    now_month = datetime.datetime.strptime(str(datetime.datetime.now())[:7], "%Y-%m")
    if start_time == now_month == end_time:
        return []
    else:
        month_list = []
        for x in range(month_count):
            year, month = [int(y) for y in str(start_time)[:7].split("-")]
            month = month + x
            if month > 12:
                year += 1
                month -= 12
            elif month < 1:
                year -= 1
                month += 12
            year, month = str(year), str(month)
            if len(month) == 1:
                month = "0" + month
            month_list.append(year + "-" + month)
        if str(now_month)[:8] in month_list:
            month_list.remove(str(now_month)[:8])
        return month_list


# 获取从开始日期到结束日期查询存在的天数列表
def get_day_range(start_day, end_day):
    delta = datetime.timedelta(days=1)
    begin_date = datetime.datetime.strptime(start_day, '%Y-%m-%d')
    end_date = datetime.datetime.strptime(end_day, '%Y-%m-%d')
    the_date = begin_date
    while the_date < end_date:
        the_date = the_date + delta
    return str(the_date)[:10]


if __name__ == '__main__':
    # print(get_month_range("2018-11", "2019-11"))
    # print(get_day_range("2018-11-01", "2019-11-11"))
    print(time.strftime("%Y-%B-%d %H:%M:%S", time.localtime()))
