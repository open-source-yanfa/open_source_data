# 去除空格 回车 空数据校验 工具类
def data_checkout_util(content):
    newcontent = content.replace("\n", "").replace("\t", "").replace("\xa0", "") if content else ''
    return newcontent
