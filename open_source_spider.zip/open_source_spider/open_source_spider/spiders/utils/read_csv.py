import csv
import os
import time

import conf
from open_source_spider.spiders.utils.downlod_csv import *


def read_csv():
    # 下载所有的csv文件
    download_cvs()
    with open(os.path.join(conf.BASE_PATH, "result.csv")) as f:
        render = csv.reader(f)  # reader(迭代器对象)--> 迭代器对象
        # 取表头
        # header_row = next(render)
        # print(header_row)
        congress_data = []
        for row in render:
            if render.line_num > 1:
                congress_id = row[0]
                congress_url = row[1]
                if not congress_url.startswith('https://'):
                    continue
                # url = row[1]
                congress_all_info = congress_url + '/all-info?allSummaries=show'
                congress_info_text = congress_url + '/text'
                congress_data.append([congress_id, congress_all_info, congress_info_text])
        # 关闭文件流
        f.close()

        # 根据议案网站链接 去重
        congress_data_set = set()
        for i in congress_data:
            congress_data_set.add(i[1])

        # 删除result.csv文件
        if (os.path.exists('result.csv')):
            os.remove('result.csv')
        print(len(congress_data_set))
        return list(congress_data_set)

        # return congress_data
