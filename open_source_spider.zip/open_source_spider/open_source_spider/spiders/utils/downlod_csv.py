import os
import time

import glob
import shutil
import requests

from open_source_spider.spiders.utils.sql_helper import MySqlHelper

sql_helper = MySqlHelper()


def download_cvs():
    sql_helper.connect_database()
    execute_sql_result = sql_helper.execute_sql("select * from usppa_speech_keyword where crawl = 1")
    sql_helper.close()
    for every_item in execute_sql_result:
        # every_item[2]
        url = 'https://www.congress.gov/search?q={"congress":"%s","source":"%s","search":"%s"}&searchResultViewType=compact&pageSort=dateOfIntroduction:desc&pageSize=250&1ddcb92ade31c8fbd370001f9b29a7d9=628cb5675ff524f3e719b7aa2e88fe3f' % (
            116, 'legislation', every_item[2])
        r = requests.get(url)
        if not (os.path.exists('open_source_spider/download_csv')):
            os.mkdir('open_source_spider/download_csv')
        with open("open_source_spider/download_csv/congress" + "_" + time.strftime('%Y-%m-%d') + every_item[2] + ".csv",
                  "wb") as code:
            code.write(r.content)
        print('CSV Download Complete')

    # 合并所有CSV
    csv_file_name = [i for i in glob.glob('open_source_spider/download_csv/*.{}'.format('csv'))]  # 加载所有后缀为csv的文件。
    new_csv = open('result.csv', 'a')
    for i in csv_file_name:  # 循环读取同文件夹下的csv文件
        fr = open(i, 'r').readlines()
        for csv_line in fr[3:]:
            new_csv.write(csv_line)
    new_csv.close()

    # 合并文件完成后 删除下载的文件
    if (os.path.exists('open_source_spider/download_csv')):
        shutil.rmtree('open_source_spider/download_csv', True)
        print("success delete download_csv dir")
        os.mkdir('open_source_spider/download_csv')
        print("success create download_csv dir")
