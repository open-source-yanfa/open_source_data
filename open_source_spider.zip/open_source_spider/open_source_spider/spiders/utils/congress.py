import pymongo

from open_source_spider.spiders.utils.sql_helper import MySqlHelper

sql_helper = MySqlHelper()
client = pymongo.MongoClient('192.168.10.216', 27017)
db = client.congress  # 先连接系统默认数据库admin
db.authenticate("root", "123456", mechanism='SCRAM-SHA-1')
my_tab = db.congress


# 统计人物在议案中出现的次数

def congress():
    sql_helper.connect_database()
    execute_sql_result = sql_helper.execute_sql("select person_id from usppa_person_info")
    print(len(execute_sql_result))
    for index, person_id in enumerate(execute_sql_result):
        # my_doc = my_tab.find({"cosponsor_list.cosponsor_person": person_id[0]})
        my_doc = my_tab.count_documents({"cosponsor_list.cosponsor_person": person_id[0]})
        sql_helper.execute_sql(
            "Insert into zw_test (person_id,number) values (" + "\"" + str(person_id[0]) + "\"," + str(my_doc) + ");")
    sql_helper.close()

congress()
