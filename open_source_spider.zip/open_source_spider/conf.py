# factba 使用

# 日期字典表
data = {'1': 'january', '2': 'february', '3': 'march', '4': 'april', '5': 'may', '6': 'june', '7': 'july',
        '8': 'august', '9': 'september', '10': 'october', '11': 'november', '12': 'december'}

# 日期反转
data_rev = {}
for k, v in data.items():
    data_rev[v] = int(k)

import os

BASE_PATH = os.getcwd()
